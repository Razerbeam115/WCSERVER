<template>
  <div id="Education">
    <h1>{{ msg2 }}</h1>
    <h3>{{ msg25 }}</h3>
    <h3>{{ msg26 }}</h3>
    <h3>{{ msg27 }}</h3>
  </div>
</template>

<script>
export default {
  name: 'Education',
  data () {
    return {
      msg2: 'Education:',
      msg25: 'Elementary: Psalms Academy of Pampanga Inc',
      msg26: 'JHS/SHS: Guagua National Colleges',
      msg27: 'College: Holy Angel University'
     
    }
  }
}
</script>