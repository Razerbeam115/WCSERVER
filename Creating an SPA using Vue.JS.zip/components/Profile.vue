<template>
  <div id="Profile">
    <h1>{{ msg3 }}</h1>
    <h3>{{ msg12 }}</h3>
    <h3>{{ msg13 }}</h3>
    <h3>{{ msg14 }}</h3>
    <h3>{{ msg15 }}</h3>
  </div>
</template>

<script>
export default {
  name: 'Profile',
  data () {
    return {
      msg3: 'Profile:',
      msg12: 'Name: Robbie Joseph Mabanta',
      msg13: 'Course: Bachelor of Science in Information Technology',
      msg14: 'Specialization: Web Developer',
      msg15: 'Objective: Slow learner with 1 year experience of coding.'
    }
  }
}
</script>