<template>
  <div id="Skill">
    <h1>{{ msg4 }}</h1>
    <h3>{{ msg35 }}</h3>
    <h3>{{ msg36 }}</h3>
    <h3>{{ msg37 }}</h3>
    <h3>{{ msg38 }}</h3>
  </div>
</template>

<script>
export default {
  name: 'Skill',
  data () {
    return {
      msg4: 'Skills:',
      msg35: 'Training: N/A',
      msg36: 'Seminars: N/A',
      msg37: 'Technologies: Laptops, Phones, Computer Desktops',
      msg38: 'Programming Languages : Html, PHP, Python, Java, Javascript'
     
    }
  }
}
</script>