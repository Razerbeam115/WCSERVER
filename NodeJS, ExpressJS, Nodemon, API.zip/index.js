//Mabantarobbiejoseph
//Wd202
const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.send('My New App!');
});

app.get('/api/heroes', (req, res) => {
    res.send(['Superman', 'Iron Man', 'Batman', 'Hulk', 'Spiderman']);
});

app.get('/api/heroes', (req, res) => {
    res.send([{id:1, title:'Superman',publisher:'DC'}, {id:2, title:'Iron Man',publisher:'Marvel'}, {id:3, title:'Batman',publisher:'DC'}, {id:4, title:'Hulk',publisher:'Marvel'}]);
});

app.get('/api/heroes/:id', (req, res) => {
    res.send(req.params.id);
});

app.get('/api/heroes/:tittle/:publisher', (req, res) => {
    res.send(req.params);
});

app.get('/api/heroes/:tittle/:publisher', (req, res) => {
    res.send([req.params, req.query]);
});

app.listen(3000, () => console.log('Listening on port 3000'));