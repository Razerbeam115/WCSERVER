<template>
  <div class="about">
    <h1>{{title}}</h1>
    <h2>Hi! My name is Robbie Joseph Mabanta.
        I am 21 years old, i lived in Guagua, Pampanga.
        I do love playing Online games and watching movies especially K-Dramas.
    </h2>
  </div>
</template>

<script>
export default {
  name: 'about',
  data () {
    return {
      title: 'About Page'
    }
  }
}
</script>

<style scoped>
.about{ 
    margin: -50px 0px 0px 0px;
}

h2{
  font-size: 1.5em;
  font-family: 'Courier New', Courier, monospace;
  text-align: center;
  margin: 4% 0% 0% 25%;
  width: 50%;
}
</style>