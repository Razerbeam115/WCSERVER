<template>
  <div class="contact">
    <h1>{{title}}</h1>
    <h2> You can contact me Thru my Social Accounts. 
          Facebook(Robbie Joseph)
        Gmail(JosephManahan14@gmail.com)
    </h2>

  </div>
</template>

<script>  
export default {
  name: 'contact',
  data () {
    return {
      title:'Contact Page'
    }
  }
}
</script>

<style scoped>
.Home{
    margin: -50px 0px 0px 0px;
}
h2{
  font-size: 1.5em;
  font-family: 'Courier New', Courier, monospace;
  text-align: center;
  margin: 4% 0% 0% 25%;
  width: 50%;
}
</style>