<template>
  <div class="gallery">
    <h1>{{title}}</h1>
    <h2>Myself</h2>

    <img src="@/assets/profile.jpg" alt="profile">
    <p>Baguio.2022</p>
  </div>
</template>

<script>
export default {
  name: 'gallery',
  data () {
    return {
      title: 'Gallery Page'
    }
  }
}
</script>

<style scoped>
.gallery{
    margin: -50px 0px 0px 0px;
}
h1 {
  text-align: center;
  margin: 50px 0px 0px 0px;
}
h2{
  font-size: 2em;
  font-family: 'Courier New', Courier, monospace;
  text-align: center;
  margin: 4% 0% 0% 25%;
  width: 50%;
}
p{
    font-family: 'Courier New', Courier, monospace;
    text-align: center;
     margin: 0% 0% 0% 0%;
     
     
}
img{
  max-width: 20%;
  margin:  2% 0% 0% 40%;
}
</style>