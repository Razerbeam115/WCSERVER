<template>
  <div class="home">
    <h1>{{msg}}</h1>
    <h2>Hello and Welcome! Thank you for visiting this page for more inquiries please check the Contact Page</h2>
  </div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
      msg: 'Home Page'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.Home{
    margin: -50px 0px 0px 0px;
}
h2{
  font-size: 1.5em;
  font-family: 'Courier New', Courier, monospace;
  text-align: center;
  margin: 4% 0% 0% 25%;
  width: 50%;
}
</style>
